﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace AsyncHttpRequests
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("=== Асинхронная версия (async/await) ===\n");

            // Три разных API 
            string[] urls = new string[]
            {
                "https://jsonplaceholder.typicode.com/posts/1",
                "https://jsonplaceholder.typicode.com/posts/2",
                "https://jsonplaceholder.typicode.com/posts/3"
            };

            // Замеряем время выполнения
            Stopwatch stopwatch = Stopwatch.StartNew();

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Создаём задачи 
                    Task<string> task1 = LoadJsonAsync(client, urls[0]);
                    Task<string> task2 = LoadJsonAsync(client, urls[1]);
                    Task<string> task3 = LoadJsonAsync(client, urls[2]);

                    // Запускаем все задачи параллельно и ждём их завершения
                    string[] results = await Task.WhenAll(task1, task2, task3);

                    // Выводим результаты
                    for (int i = 0; i < results.Length; i++)
                    {
                        Console.WriteLine($"Ответ от {urls[i]}:");
                        Console.WriteLine(results[i]);
                        Console.WriteLine(new string('-', 50));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при выполнении запросов: {ex.Message}");
            }

            stopwatch.Stop();
            Console.WriteLine($"\nОбщее время выполнения: {stopwatch.ElapsedMilliseconds} мс");
        }

        /// Асинхронно загружает JSON по указанному URL.
        static async Task<string> LoadJsonAsync(HttpClient client, string url)
        {
            try
            {
                Console.WriteLine($"Начинаем запрос к {url}");

                // Асинхронный GET-запрос (не блокирует поток)
                HttpResponseMessage response = await client.GetAsync(url);

                // Проверяем успешность ответа (код 200-299)
                response.EnsureSuccessStatusCode();

                // Асинхронно читаем содержимое ответа
                string json = await response.Content.ReadAsStringAsync();

                Console.WriteLine($"Запрос к {url} завершён успешно");
                return json;
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Ошибка при запросе к {url}: {ex.Message}");
                throw; 
            }
        }
    }
}